# Mafia Empire: Lagos — V7.4

Mobile 3D/WebGL open-world foundation featuring Mr Bandey as the player character.

## V7.4 additions
- Lagos-style open-world foundation: roads, buildings, palms, cars and NPCs.
- Mr Bandey is player-controlled with touch joystick and keyboard fallback.
- 4 character languages: Hausa (default), Yoruba, Igbo, English.
- Menus/settings remain in English.
- Chief Musa → Bello → Safehouse mission chain.
- Wanted level and police escape objective.
- Money/health/stamina HUD, minimap, map target and interaction prompts.
- Mr Bandey reference portrait used in the title/dialogue UI.
- Android WebView packaging and GitHub Actions APK build.

## Build
GitHub Actions: run **Build Mafia Empire Lagos APK** manually or push to `main`.
